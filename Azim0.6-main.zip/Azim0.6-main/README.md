<h1 align="center"> |MR.ERROR|</h1>
<h2 align="center"> AZIM0.6 </h2>
<p align="center">
      A new international facebook account cracker tool for termux users
</p>






## <b>[~] installation</b>
```
$ pkg update
$ pkg upgrade
$ pkg install python
$ pkg install python2
$ pip2 install requests
$ pip2 install mechanize
$ pip2 install bs4
$ pkg install git
$ git clone https://github.com/Azim-vau/azim0.6.git
$ cd Azim0.6
$ python2 azim0.6.py
```

## [~] Single Command

```
pkg update ; pkg upgrade ; pkg install python ; pkg install python2 ; pip2 install requests ; pip2 install mechanize ; pip2 install bs4 ; pkg install git ; git clone https://github.com/Azim-vau/Azim0.6.git ; cd Azim0.6 ; python2 azim0.6.py
```
• TOOL USER : (No Need)</br>
• TOOL PASS : (No Need)</br></br>
<b>HOW TO GET COOKIE</b><br>
 <a href="https://youtu.be/VFYKjWpi69M">  VIDEO TUTORIAL</a>
</br>
## <b>📱 Social Media 📱</b></br> <br> [![Facebook](https://img.shields.io/badge/Facebook-AZIM-blue?style=flat-square&logo=facebook)](https://www.facebook.com/100022097600640)<br>[![Messenger](https://img.shields.io/badge/Messenger-Mr--Error-purple?style=flat-square&logo=messenger)](https://messenger.com/t/AzimVau69)<br> [![Github](https://img.shields.io/badge/Github-AZIM--MAHMUD-deepgreen?style=flat-square&logo=github)](https://github.com/Azim-vau)<br> [![Instagram](https://img.shields.io/badge/Instagram-AZIM--MAHMUD-hotpink?style=flat-square&logo=instagram)](https://instagram.com/azimmahmud143)


